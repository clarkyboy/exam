<?php

    class PersonModel {

        public $id;
        public $name;
        public $company;
        public $phone;
        public $email;
    }



?>