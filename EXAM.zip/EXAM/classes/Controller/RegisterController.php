<?php

    require_once 'classes/Service/DatabaseService.php';

    class RegisterAccessController extends Database{

        public function register($name, $email, $password){

            $sql = "INSERT INTO users (name, email, password)
            VALUES('$name', '$email', '$password')";
            $result = $this->conn->query($sql);
            $last_id = $this->conn->insert_id;
            return $last_id;
        }
        
    }



?>