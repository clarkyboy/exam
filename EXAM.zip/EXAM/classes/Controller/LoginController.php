<?php

    require_once 'classes/Service/DatabaseService.php';

    class LoginAccessController extends Database{

        public function login($name, $password){

            $sql = "SELECT * FROM users
                    WHERE name = '$name' AND password = '$password'";
            $result = $this->conn->query($sql);
            $row = $result->fetch_assoc();
            return $row;
        }
        
    }



?>