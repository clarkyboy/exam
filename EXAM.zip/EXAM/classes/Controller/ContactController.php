<?php

require_once '../classes/Service/DatabaseService.php';

class ContactAccessController extends Database {

    public function addContact($user, $name, $company, $phone, $email){
        $sql = "INSERT INTO contactlist (userid, name, company, phone, email)
            VALUES($user, $name, $company, $phone, $email)";
            $result = $this->conn->query($sql);
            return $result;
    }

    public function viewContact($userid) {
        $sql = "SELECT * FROM contactlist WHERE userid = '$userid'";
            $result = $this->conn->query($sql);
            $rows = $result->fetch_all(MYSQLI_ASSOC);
            return $rows;
    }

    public function checkDuplicate($name, $company, $phone){
        $sql = "SELECT * FROM contactlist WHERE name = '$name' AND company = '$company' AND phone = '$phone'";
        $result = $this->conn->query($sql);
        $row = $result->fetch_assoc(); // this will get a single result
        return $row;
   }

}

?>